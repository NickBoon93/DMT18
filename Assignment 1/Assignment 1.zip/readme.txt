For part 1, see Part 1.ipynb
For part 2, see Titanic.ipynb
For part 3, see DM.mlx